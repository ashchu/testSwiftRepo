import Foundation

//constant
let setVar = "Ashley"
//actual variable you can use for num, string, etc
var testVar = 16
//print(setVar)
//print(testVar)

print("My name is \(setVar) and I am \(testVar)")


//You can run different types using Any, but can specify what the
func runMyAge(age: Int, name: String) -> Any{
    let setAge = 2019 - 2000
    let difference = age - setAge
    if(difference<0){
        return "dang you are young. 0";
    }
    else{
        return difference;
    }
}

runMyAge(age: testVar, name: setVar)

//Making a class for a new type/obj

class MusicalArtist{
    let instrument: String
    let name: String
    var yearsOfExperience: Int
    var bestSong: String
    
    init(instrument: String, name: String, yearsOfExperience: Int, bestSong: String) {
//        this is an instance
        self.instrument = instrument
        self.name = name
        self.yearsOfExperience = yearsOfExperience
        self.bestSong = bestSong
    }
    func bio() -> String {
        return "Quick lil' bio 'bout our fav artist \(name) who \(instrument) and has \(yearsOfExperience) years of experience and the hit jam \(bestSong)!!"
    }
}

//creating an object type storing information about artist 
let conanGray = MusicalArtist(instrument: "sings", name: "Conan Gray", yearsOfExperience: 4, bestSong: "Generation Why")
print(conanGray.bio())

